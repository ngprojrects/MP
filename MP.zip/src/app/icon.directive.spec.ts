import { IconDirective } from './icon.directive';

describe('IconDirective', () => {
  it('should create an instance', () => {
    const directive = new IconDirective();
    expect(directive).toBeTruthy();
  });
});
