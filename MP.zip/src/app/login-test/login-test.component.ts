import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-test',
  templateUrl: './login-test.component.html',
  styleUrls: ['./login-test.component.css']
})
export class LoginTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

    onLoggedin() {
        localStorage.setItem('isLoggedin', 'true');
    }

}
