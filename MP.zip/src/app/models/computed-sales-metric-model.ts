export class ComputedSalesMetricsModel {
    public netAverage: number;
    public discountPercentage: number;
    public taxPercentage: number;
    public tipsPercentage: number;
    public totalAverage: number;

    public transactions: number;
    public sales: number;
    public discounts: number;
    public net: number;
    public fee: number;
    public tax: number;
    public tips: number;
    public total: number;
  }
