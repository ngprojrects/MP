export class NumberDataMap {
    public key: string;
    public value: number;
  }
  