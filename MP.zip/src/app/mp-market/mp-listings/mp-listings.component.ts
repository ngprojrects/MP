import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mp-listings',
  templateUrl: './mp-listings.component.html',
  styleUrls: ['./mp-listings.component.css']
})
export class MpListingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
