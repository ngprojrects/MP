import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mp-onthemarket',
  templateUrl: './mp-onthemarket.component.html',
  styleUrls: ['./mp-onthemarket.component.css']
})
export class MpOnTheMarketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
