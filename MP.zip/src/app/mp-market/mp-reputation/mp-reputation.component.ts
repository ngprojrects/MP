import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mp-reputation',
  templateUrl: './mp-reputation.component.html',
  styleUrls: ['./mp-reputation.component.css']
})
export class MpReputationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
