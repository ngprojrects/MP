import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mp-social',
  templateUrl: './mp-social.component.html',
  styleUrls: ['./mp-social.component.css']
})
export class MpSocialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
