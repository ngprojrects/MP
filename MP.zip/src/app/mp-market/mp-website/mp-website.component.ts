import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mp-website',
  templateUrl: './mp-website.component.html',
  styleUrls: ['./mp-website.component.css']
})
export class MpWebsiteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
