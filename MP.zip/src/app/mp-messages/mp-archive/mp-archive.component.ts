import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mp-archive',
  templateUrl: './mp-archive.component.html',
  styleUrls: ['./mp-archive.component.css']
})
export class MpArchiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
