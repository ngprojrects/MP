import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mp-partners-form',
  templateUrl: './mp-partners-form.component.html',
  styleUrls: ['./mp-partners-form.component.css']
})
export class MpPartnersFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
