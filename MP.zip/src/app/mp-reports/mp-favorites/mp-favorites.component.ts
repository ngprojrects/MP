import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mp-favorites',
  templateUrl: './mp-favorites.component.html',
  styleUrls: ['./mp-favorites.component.css']
})
export class MpFavoritesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
