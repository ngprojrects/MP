export const environment = {
    production: false,
    apiUrl: 'https://us-e-apim.azure-api.net/mobilereports/pos/reports/'
  };
