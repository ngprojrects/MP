export const environment = {
  production: true,
  apiUrl: 'https://us-e-apim.azure-api.net/mobilereports/pos/reports/'
};
